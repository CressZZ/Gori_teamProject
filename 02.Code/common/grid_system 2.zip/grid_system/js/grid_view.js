$(document).on('keydown', function(e){
  if(e.which == 71 && 16){
    $("body").toggleClass("grid-on");G
  }
});
